<?php

namespace CL\ComposerInit;

use CL\ComposerInit\Prompt;
use CL\ComposerInit\TemplateHelper;
use Symfony\Component\Console\Output\OutputInterface;

class Template
{
    public static function getTemplateValues(OutputInterface $output, TemplateHelper $template)
    {
        return $template->retrieveParams($output, array(
            new Prompt\Title(),
            new Prompt\AuthorName(),
        ));
    }
}
