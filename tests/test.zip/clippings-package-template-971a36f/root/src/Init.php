<?php

namespace CL\TestNamespace;

/**
 * @author    {%author_name%}
 * @license   http://spdx.org/licenses/BSD-3-Clause
 */
class Init
{

}
