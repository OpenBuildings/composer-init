<?php

/**
 * @author    {% author_name %}
 */
class Init {}
