<?php

namespace CL\%%REPO_NAMESPACE%%;

/**
 * @author    %%AUTHOR_NAME%% <%%AUTHOR_EMAIL%%>
 * @copyright (c) %%YEAR%% Clippings Ltd.
 * @license   http://spdx.org/licenses/BSD-3-Clause
 */
class Init
{

}
