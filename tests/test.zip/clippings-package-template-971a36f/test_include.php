<?php

function test_include_function() {
    return 'test';
}
